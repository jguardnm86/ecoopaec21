## Artifacts for RQ2 (performance of jGuard-annotated libraries)

To compile the benchmark code against the original BouncyCastle library, use

```
javac -cp bouncycastle.jar benchmark/Benchmark.java
```

To then run the benchmark with the original implementation, use

```
java -cp bouncycastle.jar:. benchmark.Benchmark
```

To instead run the benchmark against the jGuard-annotated implementation, use

```
java -cp verified_bc.jar:. benchmark.Benchmark
```
